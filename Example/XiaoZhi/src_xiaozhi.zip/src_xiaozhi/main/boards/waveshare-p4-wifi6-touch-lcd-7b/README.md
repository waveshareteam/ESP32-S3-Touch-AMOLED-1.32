# Waveshare ESP32-P4-WIFI6-Touch-LCD-7B


[ESP32-P4-WIFI6-Touch-LCD-7B](https://www.waveshare.com/esp32-p4-wifi6-touch-lcd-7b.htm) is waveshare electronics designed an intelligent 86 box based on ESP32-P4 module equipped with a 1024*600 IPS capacitive touch screen


## Configuration

Configuration in `menuconfig`.

Selection Board Type `Xiaozhi Assistant --> Board Type`
- Waveshare ESP32-P4-WIFI6-Touch-LCD-7B